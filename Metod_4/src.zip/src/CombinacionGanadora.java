
public class CombinacionGanadora {
	boolean encontrado=false;
	int solucion=0;
	int numerosUsados=10;
	int [] original = null;
	
	
	public CombinacionGanadora( int[] original) {
		this.original = original;
	}
	public boolean isEncontrado() {
		return encontrado;
	}
	public void setEncontrado(boolean encontrado) {
		this.encontrado = encontrado;
	}
	public int getSolucion() {
		return solucion;
	}
	public void setSolucion(int solucion) {
		this.solucion = solucion;
	}
	public int getNumerosUsados() {
		return numerosUsados;
	}
	public void setNumerosUsados(int numerosUsados) {
		this.numerosUsados = numerosUsados;
	}
	public int[] getOriginal() {
		return original;
	}
	public void setOriginal(int[] original) {
		this.original = original;
	} 
	
	
}
