import java.util.ArrayList;

public class Variaciones {

  // vector original sobre el que se van a calcular las variaciones
  int [] original = null; 
  // almacen de soluciones
  public ArrayList<int[]> soluciones = null;

  /**
  * constructor : a partir de un vector
  */
  public Variaciones(int[] v) {
    original = v;
    soluciones = new ArrayList<int[]>();
  }

  /** 
  * LLamada inicial al m�todo
  * Soluci�n: todo a 0, etapa = 0
  */
  
  public void variacionesMN(int n) {
    // Inicializaci�n de la soluci�n inicial con la longitud n
    int [] primerEstado = new int[n];
    variacionesMN(primerEstado, 0);
  }

  /**
  * m�todo backtracking
  * @param estado: soluci�n actual
  * @param etapa: nivel del arbol por el que vamos buscando
  */
  private void variacionesMN(int[] estado, int etapa){
    if (etapa == estado.length){  // test de soluci�n
      //util.outputTuple(estado, '\n'); // --> mostrar soluci�n
      // acumular soluci�n
      int[] copia=new int[estado.length];
      System.arraycopy(estado,0,copia,0,estado.length);
      soluciones.add(copia);
    } else {
      // generaci�n de descendientes: a�adir elementos del vector original
      for(int k=0; k < original.length; k++) { 
        if (isValid(estado, etapa, original[k])){ // test de fracaso
          estado[etapa] = original[k];  // a�adir nueva soluci�n
          variacionesMN(estado,etapa+1);
          // no es necesario "borrar" se sobrescribe
        }
      }
    }
  }

  /**
  * test de validez/fracaso
  * @param actual: vector con la soluci�n actual
  * @param etapa: etapa actual, lugar por el que se est� completanto
  * @param nuevo: valor a introducir
  */
  private boolean isValid(int[] actual, int etapa, int nuevo) {
    boolean vale=true;
    for(int n = 0; n <etapa && vale;n++) 
      if(actual[n] == nuevo) vale=false;
    return vale;
  }
  
}
