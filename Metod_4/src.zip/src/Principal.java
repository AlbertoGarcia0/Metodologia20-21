import java.util.*;
import java.util.Scanner;
import java.util.ArrayList;


public class Principal {
    public static void main(String[] args) {
    	Scanner teclado = new Scanner(System.in);
        int numerosGrandes;
        int[] conjuntoGrandes = {25, 50, 75, 100};
        int[] vector = {0, 0, 0, 0, 0, 0};
        int[] conjuntoPeque�os = {1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10};
        int[] numeroJugador = new int[6];
        ArrayList<CombinacionGanadora> arrayCombinaciones = new ArrayList<CombinacionGanadora>();
        String cadenaNumeros = "Los numeros con los que se va a jugar son:";

        int objetivo = (int) (Math.random() * (999 - 101)) + 101;
        
        do{
            System.out.println("Seleccione el n�mero de numeros grandes:");
            numerosGrandes = teclado.nextInt();
        }while(numerosGrandes< 0 || numerosGrandes>4);
        
        GenerarNumerosParaJugar(numerosGrandes, conjuntoGrandes, conjuntoPeque�os, numeroJugador);
        for(int i=0 ;i<numeroJugador.length;i++)
        	cadenaNumeros+=" "+numeroJugador[i];
        System.out.println(cadenaNumeros);
        System.out.println("El n�mero objetivo es: "+ objetivo);
        
        Variaciones v = new Variaciones(numeroJugador);
        v.variacionesMN(6);
        System.out.println("N� de soluciones:\t" + v.soluciones.size());
        for (int[] s : v.soluciones) {
        	for(int i=0;i<s.length;i++) {
        		vector[i]=s[i];
        		System.out.print(s[i]+" ");
        	}
        	CombinacionGanadora combi = new CombinacionGanadora(vector);
        	System.out.println("");
        	arrayCombinaciones.add(combi);
        }
        System.out.println("hola");
        teclado.close();
    }

	private static void GenerarNumerosParaJugar(int numerosGrandes, int[] conjuntoGrandes, int[] conjuntoPeque�os, int[] numeroJugador) {
		int posicion;
		int valor;
        
        if(numerosGrandes!=0) {
        	for (int i = 0; i < numerosGrandes; i++) {
        		do {
        			posicion = new Random().nextInt(4);
        			valor=conjuntoGrandes[posicion];
        			numeroJugador[i]=conjuntoGrandes[posicion];
        			conjuntoGrandes[posicion]=0;
        		}while(valor==0);
        	}
        }
        
        for(int i = numerosGrandes; i<6; i++) {
    		do {
    			posicion = new Random().nextInt(20);
    			valor=conjuntoPeque�os[posicion];
    			numeroJugador[i]=conjuntoPeque�os[posicion];
    			conjuntoPeque�os[posicion]=0;
    		}while(valor==0);
        }
	}
}